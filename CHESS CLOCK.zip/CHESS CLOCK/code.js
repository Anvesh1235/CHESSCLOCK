var x = 300;
var y = 300;
onEvent("button1", "click", function( ) {
  stopTimedLoop();
  setProperty("button1", "background-color", "black");
  setProperty("button2", "background-color", "blue");
var a = timedLoop(1000, function(){
  x = x - 1;
  setNumber("button2", x);
});
});
onEvent("button3", "click", function( ) {
  stopTimedLoop();
  stopTimedLoop();
  x = 300;
  setNumber("button1", x);
  y = 300;
  setNumber("button2", y);
});
onEvent("button4", "click", function( ) {
  stopTimedLoop();
  stopTimedLoop();
});
onEvent("button2", "click", function( ) {
  stopTimedLoop();
  setProperty("button2", "background-color", "black");
  setProperty("button1", "background-color", "blue");
  var c = timedLoop(1000, function(){
   y = y - 1;
   setNumber("button1", y);
});
});
